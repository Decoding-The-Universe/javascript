
function timer(){
    var k = 0
    document.getElementById('entrace-page').remove()
    while(k<=1){
    setTimeout(function(){document.getElementById('main-body').style.opacity = k}, 500)
    k+=0.1
    }
    document.body.style.backgroundImage = null;
    
}
//welcome audio
var welcome = new Audio('audio.mp3')
// hit audio
var click = new Audio('hit.mp3')
// win audio
var win = new Audio('photos/sounds/cash.mp3')
// lost audio
var lost= new Audio('photos/sounds/aww.mp3') ;
// stand audio
var stand_music = new Audio('coins-collecting.mp3')
// reset
var reset_music = new Audio('blackjack-magic.mp3')
function _play(){
    
    welcome.play()
    welcome.play()

}
var HIT1 = true
var STAND1 = true
var HIT2 = false


function ask_names(){
    // also changes names
    var player_1 = prompt("Enter Player 1 Name: ")
    var player_2 = prompt("Enter Player 2 Name: ") 
    document.getElementById('player-1-name').innerHTML = player_1
    
    document.getElementById('player-2-name').innerHTML = player_2
}

// 12 images
var img2 = 'https://cdn2.bigcommerce.com/n-d57o0b/1kujmu/products/297/images/924/2D__57497.1440113502.1280.1280.png?c=2'
var img_ace = 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Playing_card_heart_A.svg/1200px-Playing_card_heart_A.svg.png'
var img3 = 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Playing_card_heart_3.svg/480px-Playing_card_heart_3.svg.png'
var img4 = 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Playing_card_heart_4.svg/819px-Playing_card_heart_4.svg.png'
var img5 = 'https://i.pinimg.com/originals/33/71/c4/3371c4a9a3db09cbebb874f2ba292209.png'
var img6 = 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Playing_card_diamond_6.svg/819px-Playing_card_diamond_6.svg.png'
var img7 = 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/Playing_card_heart_7.svg/1200px-Playing_card_heart_7.svg.png'
var img8 = 'https://storage.needpix.com/rsynced_images/eight-28248_1280.png'
var img9 = 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Playing_card_heart_9.svg/1200px-Playing_card_heart_9.svg.png'
var img_jac = 'https://i.pinimg.com/originals/af/63/b5/af63b56a66041d87388660259d01b367.png'
var img_king = 'https://i.pinimg.com/originals/0b/94/39/0b9439d7f56fbdf043bafde14c54b82e.png'
var img_queen = 'https://media.istockphoto.com/photos/playing-card-queen-of-hearts-picture-id166089285'


function random(){
    var r =Math.floor(Math.random()*11)
    return r
}
function ace_logic(x){
    var previous = document.getElementById(x).textContent
    var ace_score;
    if(parseInt(previous)<=10){
        var ace_score = 11
    }
    else{
        var ace_score = 1
    }
    return ace_score
    }

function database(x){
    var r = random()
    var Data = {
        0 : {'image':img_ace, 'score': ace_logic(x)}, 
        1: {'image':img2, 'score':2}, 
        2 : {'image':img3, 'score':3}, 
        3 : {'image':img4, 'score':4}, 
        4 : {'image':img5, 'score':5}, 
        5 : {'image':img6, 'score':6}, 
        6 : {'image':img7, 'score':7}, 
        7 : {'image':img8, 'score':8}, 
        8 : {'image':img9, 'score':9}, 
        9 : {'image':img_king, 'score':10}, 
        10 : {'image':img_queen, 'score':10}, 
        11 : {'image':img_jac, 'score':10}, 
    }
    return Data[r]
    

 }
 function add_img(x, y){
    var img =document.createElement('img')
    img.src = y
    img.style.height ='150px';
    img.style.width ='100px';
    img.style.margin = "5px"
    var z = document.getElementById(x)
    z.appendChild(img)
}
function checkscore(x, y){
    var pre = document.getElementById(x).textContent
    var updated = parseInt(pre) + parseInt(y)
    var output;
    var sound;
    if(parseInt(updated) > 21){
        var output = 'You Lost';
        var score_last = pre;
        HIT1 = false
        HIT2 = true
        STAND1 = false
        var player_2 = document.getElementById('player-2-name').textContent
        document.getElementById('current-state').innerHTML = player_2 + "'s Turn"
        var sound = lost
    }
    else if(parseInt(updated) === 21){
        var output = 'You Won'
        HIT1 = false
        HIT2 = true
        STAND1 = false
        var player_2 = document.getElementById('player-2-name').textContent
        document.getElementById('current-state').innerHTML = player_2 + "'s Turn"
        var sound = win
    }
    else{
        var output = parseInt(updated)
        var sound = click
    }
    if(score_last == ''){
        list = [output, sound]
    }
    else{
        list = [output, sound, score_last]
    }
    return list

}
function update_score(x, y){undefined
    if(x == 'player-1-div'){
        var out = checkscore("player-1-score", y)
        }
    else{
        var out = checkscore("player-2-score", y)
    }
    return out
}

function color_decider(x){
    var color ;
    if(isNaN(parseInt(x))== false){
        var color = 'orange';
    }
    else if(x == 'You Won'){
        var color = 'green';
    }
    else{
        var color = 'red';
    }
    return color

}
function score_decider2(x, y, z){
    var pre = document.getElementById(x).textContent
    var updated = parseInt(pre) + parseInt(y)
    var output;
    var sound;
    
    var player_1_score = document.getElementById('player-1-score').textContent
    if(parseInt(updated) > 21){
        var output = 'You Lost';
        var sound = lost
        HIT2 = false
    }
    
    else if(parseInt(updated) === 21){
        var output = 'You Won'
        var sound = win
        HIT2 = false
    }
    // player1 standed and player2's score is more than player1 1 score
    else if(isNaN(parseInt(player_1_score))==false && parseInt(updated)<21 && parseInt(updated) > parseInt(player_1_score)){
        var output = 'You Won'
        var sound = win
        HIT2 = false
    }
    else if(z != 'undefined' && parseInt(updated)<21 && parseInt(updated) > parseInt(z)){
        var output = 'You Won'
        var sound = win
        HIT2 = false
    }
    else{
        var output = updated
        var sound = click
    }
    var list = [output, sound]
    return list
}

function change_game_state(){
    var current_state = document.getElementById('current-state')
    var current_state_text = document.getElementById('current-state').textContent
    var player1_score = document.getElementById('player-1-score').textContent
    var player2_score = document.getElementById('player-2-score').textContent
    var player_1 = document.getElementById('player-1-name').textContent
    var player_2 = document.getElementById('player-2-name').textContent
    var player_1_draws = document.getElementById('player-1-draws').textContent
    var player_2_draws = document.getElementById('player-2-draws').textContent
    var player_1_wins = document.getElementById('player-1-wins').textContent
    var player_2_wins = document.getElementById('player-2-wins').textContent
    var player_1_losses = document.getElementById('player-1-losses').textContent
    var player_2_losses = document.getElementById('player-2-losses').textContent
    if(isNaN(parseInt(player1_score)) == isNaN(parseInt(player2_score)) == true &&  player1_score == player2_score){
        document.getElementById('current-state').innerHTML = "Game Tied"
        current_state.style.color = 'yellow'
        document.getElementById('player-1-draws').innerHTML = parseInt(parseInt(player_1_draws) + 1)
        document.getElementById('player-2-draws').innerHTML = parseInt(parseInt(player_2_draws) + 1)

    }
    else if(player1_score == 'You Won' && player2_score == 'You Lost'){
        document.getElementById('current-state').innerHTML = player_1 + ' Won'
        current_state.style.color = 'green'
        document.getElementById('player-1-wins').innerHTML = parseInt(parseInt(player_1_wins) + 1)
        document.getElementById('player-2-losses').innerHTML = parseInt(parseInt(player_2_losses) + 1)
    }
    else if(player2_score == 'You Won' && player1_score == 'You Lost'){
        document.getElementById('current-state').innerHTML = player_2 + ' Won'
        current_state.style.color = 'green'
        document.getElementById('player-1-losses').innerHTML = parseInt(parseInt(player_1_losses) + 1)
        document.getElementById('player-2-wins').innerHTML = parseInt(parseInt(player_2_wins) + 1)

    }
    else if(isNaN(parseInt(player1_score)) == false && player2_score == 'You Lost'){
        document.getElementById('current-state').innerHTML = player_1 + ' Won'
        current_state.style.color = 'green'
        document.getElementById('player-1-wins').innerHTML = parseInt(parseInt(player_1_wins) + 1)
        document.getElementById('player-2-losses').innerHTML = parseInt(parseInt(player_2_losses) + 1)
        
    }
    else if(isNaN(parseInt(player1_score)) == false && player2_score == 'You Won'){
        document.getElementById('current-state').innerHTML = player_2 + ' Won'
        current_state.style.color = 'green'
        document.getElementById('player-1-losses').innerHTML = parseInt(parseInt(player_1_losses) + 1)
        document.getElementById('player-2-wins').innerHTML = parseInt(parseInt(player_2_wins) + 1)
    }
    else{
        document.getElementById('current-state').innerHTML = current_state_text
    }


    // deifine if else conditions for the current state
}
function update_after_three_months(){
    document.getElementById('previous-score').innerHTML = pre;
}
var output_of_hit1_if_lost = 'undefined';
function hit1(){
    if(HIT1 == true){
        var player_1 = document.getElementById('player-1-name').textContent
        document.getElementById('current-state').innerHTML = player_1 + "'s Turn"
        var out = database("player-1-score")    
        add_img("player-1-div", out['image'])
        var output = update_score("player-1-div", out['score'])
        var result = output[0]
        document.getElementById("player-1-score").innerHTML = result;
        var id = document.getElementById('player-1-score')
        var colour = color_decider(result)
        id.style.color = colour
        var sound = output[1]
        sound.play()
        if(output.length == 3){
            output_of_hit1_if_lost = output[2]
        }
        
        }

}
    



function stand1(){
    if(STAND1 == true){
        HIT1 = false
        HIT2 = true
        var player_2 = document.getElementById('player-2-name').textContent
        stand_music.play()
        document.getElementById('current-state').innerHTML = player_2 + "'s Turn"
        STAND1 = false
    }

// change game state
}

function hit2(){
    if(HIT2 == true){
        var storing_output_of_hit1 = output_of_hit1_if_lost
        var out2 = database("player-2-score")    
        add_img("player-2-div", out2['image'])
        var result = score_decider2("player-2-score", out2['score'], storing_output_of_hit1)
        var result_color = color_decider(result[0])
        document.getElementById('player-2-score').innerHTML = result[0]
        var id = document.getElementById('player-2-score')
        id.style.color = result_color
        var audio = result[1]
        audio.play()
        change_game_state()
        
    }
    hit1()
}


function reset(){

   if(HIT2 == false && HIT1 == false && STAND1 == false){
        for (var i= document.images.length; i-->0;)
        document.images[i].parentNode.removeChild(document.images[i]);
        document.getElementById('player-1-score').innerHTML = 0;
        document.getElementById('player-2-score').innerHTML = 0;
        document.getElementById('current-state').innerHTML = "Let's Play"
        HIT1 = true
        HIT2 = false
        STAND1 = true
        var p1 = document.getElementById('player-1-score')
        var p2 = document.getElementById('player-2-score')
        var c = document.getElementById('current-state')
        p1.style.color = 'orange'
        p2.style.color  = 'orange'
        c.style.color = 'black'
        reset_music.play()
   }
}


