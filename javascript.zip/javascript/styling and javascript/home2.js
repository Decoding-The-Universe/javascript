function cal_text(x){
    var H1 = document.createElement('h1')
    var t = document.createTextNode(x)
    H1.appendChild(t)
    document.getElementById('text').appendChild(H1)
}
function rhs(){
    var tex = document.getElementById('text').textContent
    var symbols = ['+', '/', '-', '*', '$', '^']
    var n = 0;
    var m = 0;
    var sy;
    while(n<tex.length){

        while(m<symbols.length){



                if(tex[n] == symbols[m]){
                    var sy = tex[n];
                    break;
                }
                m+=1;
        }
        var m = 0;
        n+=1
    }
    return sy

}
function equals(){
    var text = document.getElementById('text').textContent
    var symbol = rhs()
    var z = text.split(symbol)
    return z

}
function backspace(){
    var text = document.getElementById('text').textContent;
    var replaced = text.slice(0,-1);
    document.getElementById('text').innerHTML = "<h1>"+replaced+"</h1>";
}
function calculation(){

    var list = equals()
    var s = rhs()
    // SWITCH CASE IS WORKING CORRECTLY  
    switch(s){
        case '+':
             var answer = parseInt(list[0]) + parseInt(list[1]);
             break;
        case '-': 
            var answer = parseInt(list[0])-parseInt(list[1]);
            break;
     /*   case '$': 
            var answer = parseInt(list[0])+parseInt(list[1]);
            break; */
        case '^': 
            var answer = Math.pow(parseInt(list[0]),parseInt(list[1]));
            break;
        case '/': 
            var answer = parseInt(list[0])/parseInt(list[1]);
            break;
        case '*': 
            var answer = parseInt(list[0])*parseInt(list[1]);
            break;
        }
        return answer

}
function front_end(){
    var final_result = calculation()
    
    if(Number.isNaN(final_result) == true){
        alert('Invalid Input Please Try Again')
    }else{
        document.getElementById('text').innerHTML = "<h1 style='color:green;'>"+final_result+"</h1>";   
    }
    


}
function remove_all(){
    document.getElementById('text').remove()

}
function sin(){
    text = document.getElementById('text').textContent
    document.getElementById('text').innerHTML = '<h1>'+text + 'sin()</h1>'
}